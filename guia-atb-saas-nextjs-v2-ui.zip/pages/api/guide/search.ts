import type { NextApiRequest, NextApiResponse } from "next";
import Fuse from "fuse.js";
import { getServerSession } from "next-auth";
import { authOptions } from "@/pages/api/auth/[...nextauth]";
import { getPublicGuide, getPrivateGuide } from "@/lib/guide";
import { userHasActiveSubscription } from "@/lib/subscription";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const q = (req.query.q as string | undefined)?.trim() ?? "";
  if (!q) return res.status(200).json({ results: [] });

  const session = await getServerSession(req, res, authOptions);
  const isLogged = Boolean(session?.userId);
  const hasPremium = isLogged ? await userHasActiveSubscription(session!.userId!) : false;

  const guide = hasPremium ? getPrivateGuide() : getPublicGuide();

  // Search over title + rawText if present
  const fuse = new Fuse(guide.nodes, {
    keys: [
      { name: "title", weight: 0.7 },
      { name: "rawText", weight: 0.3 },
      { name: "system", weight: 0.2 },
    ],
    includeScore: true,
    threshold: 0.35,
    ignoreLocation: true,
    minMatchCharLength: 2,
  });

  const hits = fuse.search(q).slice(0, 20).map((h) => {
    const n: any = h.item;
    return {
      id: n.id,
      title: n.title,
      slug: n.slug,
      system: n.system,
      isDemo: Boolean(n.isDemo),
      locked: !n.isDemo && !hasPremium,
      score: h.score,
    };
  });

  return res.status(200).json({ results: hits, premium: hasPremium });
}
