import type { NextApiRequest, NextApiResponse } from "next";
import { getServerSession } from "next-auth";
import { authOptions } from "@/pages/api/auth/[...nextauth]";
import { getPublicGuide, getPrivateGuide, findNodeBySlug } from "@/lib/guide";
import { userHasActiveSubscription } from "@/lib/subscription";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const slug = (req.query.slug as string) ?? "";
  if (!slug) return res.status(400).json({ error: "Missing slug" });

  const publicGuide = getPublicGuide();
  const publicNode = findNodeBySlug(publicGuide, slug);
  if (!publicNode) return res.status(404).json({ error: "Not found" });

  if (publicNode.isDemo) {
    return res.status(200).json({ node: publicNode, mode: "demo" });
  }

  const session = await getServerSession(req, res, authOptions);
  if (!session?.userId) return res.status(401).json({ error: "Login required" });

  const ok = await userHasActiveSubscription(session.userId);
  if (!ok) return res.status(402).json({ error: "Premium required" });

  const privateGuide = getPrivateGuide();
  const privateNode = findNodeBySlug(privateGuide, slug);
  if (!privateNode) return res.status(404).json({ error: "Not found" });

  return res.status(200).json({ node: privateNode, mode: "premium" });
}
