import type { NextApiRequest, NextApiResponse } from "next";
import { getServerSession } from "next-auth";
import { authOptions } from "@/pages/api/auth/[...nextauth]";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const session = await getServerSession(req, res, authOptions);
  if (!session?.userId) return res.status(401).json({ error: "Unauthorized" });

  const sub = await prisma.subscription.findUnique({ where: { userId: session.userId } });
  if (!sub?.stripeCustomerId) return res.status(400).json({ error: "No customer" });

  const returnUrl = (req.body?.returnUrl as string) ?? "http://localhost:3000/app/settings";

  const portal = await stripe.billingPortal.sessions.create({
    customer: sub.stripeCustomerId,
    return_url: returnUrl,
  });

  return res.status(200).json({ url: portal.url });
}
