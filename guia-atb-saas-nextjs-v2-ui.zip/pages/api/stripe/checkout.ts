import type { NextApiRequest, NextApiResponse } from "next";
import { getServerSession } from "next-auth";
import { authOptions } from "@/pages/api/auth/[...nextauth]";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const session = await getServerSession(req, res, authOptions);
  if (!session?.userId) return res.status(401).json({ error: "Unauthorized" });

  const { plan } = req.body as { plan?: "monthly" | "yearly" };
  const priceId =
    plan === "yearly" ? process.env.STRIPE_PRICE_YEARLY : process.env.STRIPE_PRICE_MONTHLY;

  if (!priceId) return res.status(500).json({ error: "Missing Stripe price id" });

  const user = await prisma.user.findUnique({ where: { id: session.userId } });
  if (!user?.email) return res.status(400).json({ error: "User email required" });

  let sub = await prisma.subscription.findUnique({ where: { userId: user.id } });

  if (!sub) {
    sub = await prisma.subscription.create({ data: { userId: user.id, status: "inactive" } });
  }

  let customerId = sub.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: user.email,
      metadata: { userId: user.id },
    });
    customerId = customer.id;
    await prisma.subscription.update({
      where: { userId: user.id },
      data: { stripeCustomerId: customerId },
    });
  }

  const successUrl = process.env.STRIPE_SUCCESS_URL ?? "http://localhost:3000/app";
  const cancelUrl = process.env.STRIPE_CANCEL_URL ?? "http://localhost:3000/pricing";

  const checkout = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price: priceId, quantity: 1 }],
    allow_promotion_codes: true,
    success_url: successUrl,
    cancel_url: cancelUrl,
    subscription_data: { metadata: { userId: user.id } },
  });

  return res.status(200).json({ url: checkout.url });
}
