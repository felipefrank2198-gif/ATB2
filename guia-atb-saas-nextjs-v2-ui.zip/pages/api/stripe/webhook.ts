import type { NextApiRequest, NextApiResponse } from "next";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";

export const config = {
  api: { bodyParser: false },
};

async function buffer(req: NextApiRequest) {
  const chunks: Uint8Array[] = [];
  for await (const chunk of req) chunks.push(typeof chunk === "string" ? Buffer.from(chunk) : chunk);
  return Buffer.concat(chunks);
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end("Method not allowed");

  const sig = req.headers["stripe-signature"];
  const whsec = process.env.STRIPE_WEBHOOK_SECRET;

  if (!sig || !whsec) return res.status(400).send("Missing signature/secret");

  const buf = await buffer(req);

  let event;
  try {
    event = stripe.webhooks.constructEvent(buf, sig, whsec);
  } catch (err: any) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as any;
        const customerId = session.customer as string | null;
        const subscriptionId = session.subscription as string | null;
        const userId = session?.metadata?.userId as string | undefined;

        if (userId) {
          await prisma.subscription.upsert({
            where: { userId },
            update: { stripeCustomerId: customerId ?? undefined, stripeSubscriptionId: subscriptionId ?? undefined },
            create: { userId, stripeCustomerId: customerId ?? undefined, stripeSubscriptionId: subscriptionId ?? undefined, status: "incomplete" },
          });
        }
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const sub = event.data.object as any;
        const subscriptionId = sub.id as string;
        const customerId = sub.customer as string;

        const userId = (sub.metadata?.userId as string | undefined) ?? undefined;

        // Map Stripe status + period end
        const status = sub.status as string;
        const cancelAtPeriodEnd = Boolean(sub.cancel_at_period_end);
        const currentPeriodEnd = sub.current_period_end ? new Date(sub.current_period_end * 1000) : null;

        if (userId) {
          await prisma.subscription.upsert({
            where: { userId },
            update: {
              stripeCustomerId: customerId,
              stripeSubscriptionId: subscriptionId,
              status,
              cancelAtPeriodEnd,
              currentPeriodEnd: currentPeriodEnd ?? undefined,
            },
            create: {
              userId,
              stripeCustomerId: customerId,
              stripeSubscriptionId: subscriptionId,
              status,
              cancelAtPeriodEnd,
              currentPeriodEnd: currentPeriodEnd ?? undefined,
            },
          });
        } else {
          // fallback: locate by customerId
          const existing = await prisma.subscription.findFirst({ where: { stripeCustomerId: customerId } });
          if (existing) {
            await prisma.subscription.update({
              where: { userId: existing.userId },
              data: { stripeSubscriptionId: subscriptionId, status, cancelAtPeriodEnd, currentPeriodEnd: currentPeriodEnd ?? undefined },
            });
          }
        }
        break;
      }
      default:
        break;
    }
  } catch (err: any) {
    return res.status(500).send(`Webhook handler failed: ${err.message}`);
  }

  return res.json({ received: true });
}
