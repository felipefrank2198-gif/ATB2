import Link from "next/link";
import { Card, CardContent } from "@/components/ui/Card";
import { SystemBadge } from "@/components/SystemBadge";

export function PathologyCard({ title, slug, system, locked }: { title: string; slug: string; system: string; locked?: boolean }) {
  return (
    <Card className="hover:shadow-md transition">
      <CardContent className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <SystemBadge system={system} />
            {locked ? <span className="text-xs text-danger font-medium">Premium</span> : <span className="text-xs text-ok font-medium">Demo</span>}
          </div>
          <div className="mt-2 font-semibold">{title}</div>
        </div>
        <Link
          className="text-sm font-medium text-brand hover:underline"
          href={`/app/p/${slug}`}
        >
          Abrir →
        </Link>
      </CardContent>
    </Card>
  );
}
