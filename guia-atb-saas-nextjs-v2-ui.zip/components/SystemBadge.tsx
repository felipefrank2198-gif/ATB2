import { clsx } from "clsx";

const MAP: Record<string, { label: string; tone: string }> = {
  respiratorio: { label: "Respiratório", tone: "bg-blue-50 text-blue-700 border-blue-200" },
  orl: { label: "ORL", tone: "bg-indigo-50 text-indigo-700 border-indigo-200" },
  geniturinario: { label: "Geniturinário", tone: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  gastrointestinal: { label: "GI / Intra-abdominal", tone: "bg-amber-50 text-amber-800 border-amber-200" },
  "pele-partes-moles": { label: "Pele / SSTI", tone: "bg-rose-50 text-rose-700 border-rose-200" },
  osteoarticular: { label: "Osteoarticular", tone: "bg-slate-50 text-slate-700 border-slate-200" },
  "infeccoes-sistemicas": { label: "Sistêmicas / Sepse", tone: "bg-red-50 text-red-700 border-red-200" },
  "ginecologia-obstetricia": { label: "Gineco/Ob", tone: "bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200" },
  "profilaxia-cirurgica": { label: "Profilaxia Cirúrgica", tone: "bg-teal-50 text-teal-700 border-teal-200" },
};

export function SystemBadge({ system }: { system: string }) {
  const meta = MAP[system] ?? { label: system, tone: "bg-slate-50 text-slate-700 border-slate-200" };
  return (
    <span className={clsx("inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium", meta.tone)}>
      {meta.label}
    </span>
  );
}
