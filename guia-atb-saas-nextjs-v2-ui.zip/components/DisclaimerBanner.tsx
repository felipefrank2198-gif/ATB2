export function DisclaimerBanner() {
  return (
    <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
      <div className="font-semibold">Aviso clínico</div>
      <ul className="mt-2 list-disc pl-5 space-y-1">
        <li>Conteúdo educacional e de apoio — não substitui julgamento clínico.</li>
        <li>Checar alergias, função renal/hepática, gestação/lactação, interações e resistência local.</li>
        <li>Em caso de dúvida/ambiguidade, <span className="font-semibold">conferir no guia</span> e/ou em diretrizes locais.</li>
      </ul>
    </div>
  );
}
