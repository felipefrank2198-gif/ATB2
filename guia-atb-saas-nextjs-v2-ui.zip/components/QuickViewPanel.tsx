"use client";

import React from "react";
import { Card, CardContent } from "@/components/ui/Card";
import { AccordionSection } from "@/components/AccordionSection";
import type { QuickView } from "@/lib/guideParser";

export function QuickViewPanel({ qv }: { qv: QuickView }) {
  return (
    <Card>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="font-semibold">Visão rápida</div>
          <div className="text-xs text-muted">
            Exibição conservadora (sem inferências). Se faltar algo: veja a Visão completa.
          </div>
        </div>

        {qv.treatment ? (
          <AccordionSection title="Tratamento" defaultOpen>
            {qv.treatment}
          </AccordionSection>
        ) : null}

        {qv.pathogens ? (
          <AccordionSection title="Patógenos" defaultOpen>
            {qv.pathogens}
          </AccordionSection>
        ) : null}

        {qv.diagnosis ? (
          <AccordionSection title="Quadro clínico / Diagnóstico" defaultOpen>
            {qv.diagnosis}
          </AccordionSection>
        ) : null}

        {qv.severity ? (
          <AccordionSection title="Gravidade / Critérios" defaultOpen>
            {qv.severity}
          </AccordionSection>
        ) : null}

        {qv.failure ? (
          <AccordionSection title="Falha terapêutica" defaultOpen>
            {qv.failure}
          </AccordionSection>
        ) : null}

        {!qv.treatment && !qv.pathogens && !qv.diagnosis && !qv.severity && !qv.failure ? (
          <div className="text-sm whitespace-pre-wrap leading-6">
            <div className="font-medium mb-2">Trecho inicial (fallback)</div>
            <div className="text-muted">
              Não foi possível detectar blocos com segurança. Abaixo vai um recorte literal inicial.
            </div>
            <div className="mt-3">{qv.notes ?? ""}</div>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}
