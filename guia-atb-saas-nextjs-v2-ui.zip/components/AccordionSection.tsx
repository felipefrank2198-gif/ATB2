import React from "react";

export function AccordionSection({
  title,
  children,
  defaultOpen = false,
}: {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  return (
    <details className="rounded-xl border border-line bg-white" open={defaultOpen}>
      <summary className="cursor-pointer list-none px-4 py-3 font-semibold">
        {title}
      </summary>
      <div className="px-4 pb-4 pt-1 text-sm text-slate-800 whitespace-pre-wrap leading-6">
        {children}
      </div>
    </details>
  );
}
