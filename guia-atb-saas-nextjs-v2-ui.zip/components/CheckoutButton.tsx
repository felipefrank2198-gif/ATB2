"use client";

import { Button } from "@/components/ui/Button";

export function CheckoutButton({ plan, label }: { plan: "monthly" | "yearly"; label: string }) {
  return (
    <Button
      onClick={async () => {
        const r = await fetch("/api/stripe/checkout", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ plan }),
        });
        const j = await r.json();
        if (j.url) window.location.href = j.url;
        else alert(j.error ?? "Não foi possível iniciar o checkout.");
      }}
    >
      {label}
    </Button>
  );
}
