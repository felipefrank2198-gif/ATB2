"use client";

import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/Input";
import { Card, CardContent } from "@/components/ui/Card";
import Link from "next/link";
import { SystemBadge } from "@/components/SystemBadge";

type Hit = {
  id: string;
  title: string;
  slug: string;
  system: string;
  isDemo: boolean;
  locked: boolean;
};

export function SearchBar() {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Hit[]>([]);

  useEffect(() => {
    const t = setTimeout(async () => {
      const query = q.trim();
      if (!query) {
        setResults([]);
        return;
      }
      setLoading(true);
      try {
        const r = await fetch(`/api/guide/search?q=${encodeURIComponent(query)}`);
        const j = await r.json();
        setResults(j.results ?? []);
      } finally {
        setLoading(false);
      }
    }, 180);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar: patologia, patógeno, antibiótico, dose, via, duração…"
          aria-label="Busca global"
        />
        <div className="text-xs text-muted w-24 text-right">{loading ? "buscando…" : ""}</div>
      </div>

      {results.length > 0 && (
        <Card>
          <CardContent className="p-0">
            <ul className="divide-y divide-line">
              {results.map((h) => (
                <li key={h.id} className="px-4 py-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <SystemBadge system={h.system} />
                      {h.locked ? (
                        <span className="text-xs text-danger font-medium">Premium</span>
                      ) : (
                        <span className="text-xs text-ok font-medium">Demo</span>
                      )}
                    </div>
                    <div className="mt-1 font-medium">{h.title}</div>
                  </div>
                  <Link className="text-sm font-medium text-brand hover:underline" href={`/app/p/${h.slug}`}>
                    Abrir →
                  </Link>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
