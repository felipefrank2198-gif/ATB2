"use client";

import { useSearchParams } from "next/navigation";
import { signIn } from "next-auth/react";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";

export default function Login() {
  const sp = useSearchParams();
  const sent = sp.get("sent");
  const [email, setEmail] = useState("");

  return (
    <div className="max-w-md mx-auto">
      <Card>
        <CardContent className="space-y-4">
          <h1 className="text-xl font-semibold">Entrar</h1>
          <p className="text-sm text-muted">
            Enviamos um link mágico para seu e-mail (sem senha).
          </p>
          {sent ? (
            <div className="rounded-xl border border-line bg-slate-50 p-3 text-sm">
              Link enviado. Verifique sua caixa de entrada (e spam).
            </div>
          ) : null}

          <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="seuemail@..." />
          <Button
            onClick={async () => {
              if (!email.trim()) return;
              await signIn("email", { email, callbackUrl: "/app" });
            }}
          >
            Enviar link
          </Button>

          <div className="text-xs text-muted">
            Ao entrar, você concorda em usar o app de forma responsável e conforme diretrizes locais.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
