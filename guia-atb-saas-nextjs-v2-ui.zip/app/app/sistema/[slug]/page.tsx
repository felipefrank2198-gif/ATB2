import { getPublicGuide } from "@/lib/guide";
import { notFound } from "next/navigation";
import { PathologyCard } from "@/components/PathologyCard";

export default function SystemPage({ params }: { params: { slug: string } }) {
  const guide = getPublicGuide();
  const sys = guide.systems.find((s) => s.slug === params.slug);
  if (!sys) return notFound();

  const nodes = guide.nodes.filter((n) => n.system === params.slug);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">{sys.name}</h1>
        <p className="text-sm text-muted">{nodes.length} entradas (demo + premium).</p>
      </div>

      <div className="grid gap-3">
        {nodes.map((n) => (
          <PathologyCard
            key={n.id}
            title={n.title}
            slug={n.slug}
            system={n.system}
            locked={!n.isDemo}
          />
        ))}
      </div>
    </div>
  );
}
