"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { Card, CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { SystemBadge } from "@/components/SystemBadge";
import { AccordionSection } from "@/components/AccordionSection";
import { QuickViewPanel } from "@/components/QuickViewPanel";
import { buildQuickView, splitIntoSections } from "@/lib/guideParser";
import Image from "next/image";

type Node = {
  id: string;
  system: string;
  title: string;
  slug: string;
  rawText: string | null;
  isDemo?: boolean;
  source: { page_start: number; page_end: number; pdf: string; toc_page: number };
  addenda?: { type: "image"; label: string; src: string; page: number; note?: string }[];
};

export default function PathologyPage() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug;
  const [node, setNode] = useState<Node | null>(null);
  const [mode, setMode] = useState<"demo" | "premium" | "locked" | "loading">("loading");
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<"quick" | "full">("quick");

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const r = await fetch(`/api/guide/node?slug=${encodeURIComponent(slug)}`);
        if (r.status === 402) {
          const j = await r.json();
          setMode("locked");
          setError(j.error ?? "Premium required");
          return;
        }
        if (!r.ok) {
          const j = await r.json().catch(() => ({}));
          throw new Error(j.error ?? "Erro ao carregar");
        }
        const j = await r.json();
        if (!alive) return;
        setNode(j.node);
        setMode(j.mode);
      } catch (e: any) {
        setError(e.message ?? "Erro");
        setMode("locked");
      }
    })();
    return () => {
      alive = false;
    };
  }, [slug]);

  const printableDate = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const rawText = node?.rawText ?? "";
  const qv = useMemo(() => (rawText ? buildQuickView(rawText) : {}), [rawText]);
  const sections = useMemo(() => (rawText ? splitIntoSections(rawText) : []), [rawText]);

  if (mode === "loading") {
    return <div className="text-sm text-muted">Carregando…</div>;
  }

  if (mode === "locked") {
    return (
      <Card>
        <CardContent className="space-y-3">
          <div className="font-semibold">Conteúdo premium</div>
          <div className="text-sm text-muted">
            {error ?? "Faça assinatura para acessar o conteúdo completo."}
          </div>
          <div className="flex gap-2">
            <a className="text-brand font-medium hover:underline" href="/pricing">
              Ver planos →
            </a>
            <a className="text-brand font-medium hover:underline" href="/app">
              Voltar ao app →
            </a>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!node) return null;

  return (
    <div className="space-y-4 print-watermark" data-date={printableDate}>
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <SystemBadge system={node.system} />
            <span className="text-xs font-medium">{mode === "demo" ? "Demo" : "Premium"}</span>
          </div>
          <h1 className="mt-2 text-2xl font-semibold leading-tight">{node.title}</h1>
          <div className="mt-1 text-xs text-muted">
            Fonte: {node.source.pdf} • páginas {node.source.page_start}–{node.source.page_end}
          </div>
        </div>

        <div className="flex gap-2 no-print">
          <Button
            variant="ghost"
            onClick={async () => {
              const baseHeader =
                `${node.title}\n` +
                `Fonte: ${node.source.pdf} (p. ${node.source.page_start}–${node.source.page_end})\n\n`;
              const body = view === "quick" && rawText ? buildQuickView(rawText) : null;
              const quickTxt =
                body && (body.treatment || body.pathogens || body.diagnosis || body.severity || body.failure || body.notes)
                  ? [
                      body.treatment ? `TRATAMENTO\n${body.treatment}` : null,
                      body.pathogens ? `PATÓGENOS\n${body.pathogens}` : null,
                      body.diagnosis ? `QUADRO CLÍNICO / DIAGNÓSTICO\n${body.diagnosis}` : null,
                      body.severity ? `GRAVIDADE / CRITÉRIOS\n${body.severity}` : null,
                      body.failure ? `FALHA TERAPÊUTICA\n${body.failure}` : null,
                      !body.treatment && body.notes ? `TRECHO INICIAL\n${body.notes}` : null,
                    ]
                      .filter(Boolean)
                      .join("\n\n")
                  : null;
              const txt = baseHeader + (view === "quick" ? quickTxt ?? rawText : rawText);
              await navigator.clipboard.writeText(txt);
              alert(view === "quick" ? "Copiado (visão rápida)." : "Copiado (visão completa)." );
            }}
          >
            Copiar
          </Button>
          <Button
            variant="ghost"
            onClick={() => window.print()}
          >
            Imprimir/PDF
          </Button>
        </div>
      </div>

      <div className="flex gap-2 no-print">
        <Button variant={view === "quick" ? "primary" : "ghost"} onClick={() => setView("quick")}>
          Visão rápida
        </Button>
        <Button variant={view === "full" ? "primary" : "ghost"} onClick={() => setView("full")}>
          Visão completa
        </Button>
      </div>

      {view === "quick" ? (
        <QuickViewPanel qv={qv} />
      ) : (
        <div className="space-y-3">
          {sections.length ? (
            sections.map((s) => (
              <AccordionSection key={s.title} title={s.title} defaultOpen>
                {s.content}
              </AccordionSection>
            ))
          ) : (
            <Card>
              <CardContent className="text-sm whitespace-pre-wrap leading-6">
                {node.rawText ?? "Conteúdo indisponível."}
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {node.addenda?.length ? (
        <Card>
          <CardContent className="space-y-4">
            <div className="font-semibold">Tabelas do guia</div>
            {node.addenda.map((a) => (
              <div key={a.src} className="space-y-2">
                <div className="text-sm font-medium">{a.label}</div>
                {a.note ? <div className="text-xs text-muted">{a.note}</div> : null}
                <div className="overflow-auto rounded-xl border border-line">
                  <Image src={a.src} alt={a.label} width={1200} height={800} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardContent className="text-xs text-muted">
          Se algum trecho estiver ambíguo: <span className="font-medium">conferir no guia</span>.
        </CardContent>
      </Card>
    </div>
  );
}
