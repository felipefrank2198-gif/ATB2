import { Card, CardContent } from "@/components/ui/Card";
import { SearchBar } from "@/components/SearchBar";
import { getPublicGuide } from "@/lib/guide";
import { PathologyCard } from "@/components/PathologyCard";
import Link from "next/link";
import { DisclaimerBanner } from "@/components/DisclaimerBanner";

export default function AppHome() {
  const guide = getPublicGuide();
  const demo = guide.nodes.filter((n) => n.isDemo);
  const locked = guide.nodes.filter((n) => !n.isDemo);

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Guia ATB (App)</h1>
          <p className="text-sm text-muted">
            Demo libera apenas algumas patologias. Assinatura destrava o conteúdo integral do guia.
          </p>
        </div>
        <Link className="text-sm font-medium text-brand hover:underline" href="/pricing">
          Assinar →
        </Link>
      </div>

      <SearchBar />

      <DisclaimerBanner />

      <div id="sistemas" className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardContent>
            <div className="font-semibold">Demo</div>
            <div className="text-sm text-muted mt-1">Patologias liberadas para teste.</div>
            <div className="mt-4 grid gap-3">
              {demo.map((n) => (
                <PathologyCard key={n.id} title={n.title} slug={n.slug} system={n.system} locked={false} />
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <div className="font-semibold">Premium</div>
            <div className="text-sm text-muted mt-1">
              {locked.length} tópicos/patologias bloqueados. Assine para acesso completo.
            </div>
            <div className="mt-4 text-sm">
              <ul className="list-disc pl-5 space-y-1 text-slate-800">
                <li>Busca completa (inclui doses/vias/duração em todo o guia).</li>
                <li>Imprimir/PDF com marca d’água.</li>
                <li>PWA offline para assinantes.</li>
                <li>Portal Stripe para gerenciar assinatura.</li>
              </ul>
            </div>
            <div className="mt-4">
              <Link className="text-brand font-medium hover:underline" href="/pricing">Ver planos →</Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
