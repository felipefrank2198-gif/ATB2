import { getPublicGuide } from "@/lib/guide";
import { Card, CardContent } from "@/components/ui/Card";
import Link from "next/link";

export default function Coverage() {
  const guide = getPublicGuide();
  const total = guide.nodes.length;
  const demo = guide.nodes.filter((n) => n.isDemo).length;
  const locked = total - demo;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Checklist de cobertura</h1>
        <p className="text-sm text-muted">
          Validação automática: cada item do sumário do PDF deve existir como um nó no app.
        </p>
      </div>

      <Card>
        <CardContent className="text-sm">
          <div><span className="font-semibold">Total de nós:</span> {total}</div>
          <div><span className="font-semibold">Demo:</span> {demo}</div>
          <div><span className="font-semibold">Premium:</span> {locked}</div>
          <div className="mt-2 text-xs text-muted">
            Versão do conteúdo: {guide.meta.contentVersion} • Gerado em {new Date(guide.meta.generatedAt).toLocaleString("pt-BR")}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-left">
              <tr>
                <th className="p-3">Sistema</th>
                <th className="p-3">Título</th>
                <th className="p-3">Slug</th>
                <th className="p-3">Páginas</th>
                <th className="p-3">Acesso</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {guide.nodes.map((n) => (
                <tr key={n.id}>
                  <td className="p-3">{n.system}</td>
                  <td className="p-3">{n.title}</td>
                  <td className="p-3 font-mono text-xs">{n.slug}</td>
                  <td className="p-3">{n.source.page_start}–{n.source.page_end}</td>
                  <td className="p-3">
                    {n.isDemo ? (
                      <Link className="text-ok font-medium hover:underline" href={`/app/p/${n.slug}`}>Demo</Link>
                    ) : (
                      <span className="text-danger font-medium">Premium</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
