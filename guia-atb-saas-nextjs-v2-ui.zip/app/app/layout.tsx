import { getServerSession } from "next-auth";
import { authOptions } from "@/pages/api/auth/[...nextauth]";
import { redirect } from "next/navigation";
import Link from "next/link";
import { getPublicGuide } from "@/lib/guide";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.userId) redirect("/login");

  const guide = getPublicGuide();
  const version = guide.meta.contentVersion;

  return (
    <div className="grid gap-6 md:grid-cols-[260px_1fr]">
      <aside className="space-y-4">
        <div className="rounded-2xl border border-line bg-white p-4">
          <div className="text-sm font-semibold">Atalhos do plantão</div>
          <div className="mt-2 grid gap-2 text-sm">
            <Link className="hover:underline" href="/app">Busca</Link>
            <Link className="hover:underline" href="/app#sistemas">Sistemas</Link>
            <Link className="hover:underline" href="/app/settings">Assinatura</Link>
            <Link className="hover:underline" href="/app/coverage">Checklist</Link>
          </div>
          <div className="mt-4 text-xs text-muted">
            Versão do conteúdo: <span className="font-medium">{version}</span>
          </div>
        </div>

        <div className="rounded-2xl border border-line bg-white p-4">
          <div className="text-sm font-semibold">Sistemas</div>
          <div className="mt-2 grid gap-1 text-sm">
            {guide.systems.map((s) => (
              <Link key={s.slug} className="hover:underline" href={`/app/sistema/${s.slug}`}>
                {s.name} <span className="text-xs text-muted">({s.count})</span>
              </Link>
            ))}
          </div>
        </div>
      </aside>

      <section className="min-w-0">{children}</section>
    </div>
  );
}
