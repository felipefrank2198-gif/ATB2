"use client";

import { useSession, signOut } from "next-auth/react";
import { Card, CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";

export default function Settings() {
  const { data } = useSession();
  const status = (data as any)?.subscription?.status ?? "inactive";
  const periodEnd = (data as any)?.subscription?.currentPeriodEnd ?? null;

  return (
    <div className="space-y-4 max-w-2xl">
      <h1 className="text-2xl font-semibold">Assinatura</h1>

      <Card>
        <CardContent className="space-y-3">
          <div className="text-sm">
            <span className="font-semibold">Status:</span>{" "}
            <span className={status === "active" || status === "trialing" ? "text-ok font-medium" : "text-danger font-medium"}>
              {status}
            </span>
          </div>
          {periodEnd ? (
            <div className="text-sm text-muted">Período atual até: {new Date(periodEnd).toLocaleDateString("pt-BR")}</div>
          ) : null}

          <div className="flex flex-wrap gap-2">
            <Button
              variant="ghost"
              onClick={async () => {
                const r = await fetch("/api/stripe/portal", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ returnUrl: window.location.href }),
                });
                const j = await r.json();
                if (j.url) window.location.href = j.url;
                else alert(j.error ?? "Não foi possível abrir o portal.");
              }}
            >
              Gerenciar no Stripe
            </Button>

            <Button variant="ghost" onClick={() => signOut({ callbackUrl: "/" })}>
              Sair
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="text-sm text-muted">
          Pagamentos e cancelamento são geridos via Stripe. Se houver dúvida clínica, priorize diretrizes locais e stewardship.
        </CardContent>
      </Card>
    </div>
  );
}
