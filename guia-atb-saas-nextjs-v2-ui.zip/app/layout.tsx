import "@/app/globals.css";
import Link from "next/link";
import { Providers } from "@/app/providers";
import { getServerSession } from "next-auth";
import { authOptions } from "@/pages/api/auth/[...nextauth]";

export const metadata = {
  title: "Guia ATB — Plantão",
  description: "Guia prático de antibioticoterapia para plantonistas (assinatura).",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  return (
    <html lang="pt-BR">
      <body>
        <Providers>
        <header className="sticky top-0 z-40 border-b border-line bg-white/90 backdrop-blur">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <Link href="/" className="font-semibold tracking-tight">
              Guia ATB <span className="text-muted font-normal">• Plantão</span>
            </Link>
            <nav className="flex items-center gap-4 text-sm">
              <Link className="hover:underline" href="/pricing">Planos</Link>
              <Link className="hover:underline" href="/faq">FAQ</Link>
              <Link className="rounded-lg border border-line px-3 py-1.5 hover:bg-slate-50" href="/app">
                Abrir app
              </Link>
              {session?.user?.email ? (
                <span className="text-muted hidden sm:inline">{session.user.email}</span>
              ) : (
                <Link className="text-brand hover:underline" href="/login">Entrar</Link>
              )}
            </nav>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>

        <footer className="border-t border-line py-10">
          <div className="mx-auto max-w-6xl px-4 text-sm text-muted">
            © {new Date().getFullYear()} • Conteúdo baseado no “Guia Prático — Antibioticoterapia (Adulto)”. Uso clínico responsável.
          </div>
        </footer>
              </Providers>
      </body>
    </html>
  );
}
