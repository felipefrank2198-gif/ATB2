import { Card, CardContent, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/pages/api/auth/[...nextauth]";
import { CheckoutButton } from "@/components/CheckoutButton";

export default async function Pricing() {
  const session = await getServerSession(authOptions);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Planos</h1>
      <p className="text-muted max-w-2xl">
        Conteúdo completo do guia é premium. O app libera uma amostra em modo demo. Assinantes têm acesso total + offline (PWA).
      </p>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <div className="font-semibold">Mensal</div>
            <div className="text-sm text-muted">Para testar sem compromisso</div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-3xl font-semibold">R$ — <span className="text-base text-muted font-normal">/mês</span></div>
            <ul className="text-sm list-disc pl-5 space-y-1">
              <li>Acesso completo ao guia</li>
              <li>Busca e filtros</li>
              <li>PWA offline</li>
              <li>Imprimir/PDF</li>
            </ul>
            {session?.userId ? (
              <CheckoutButton plan="monthly" label="Assinar mensal" />
            ) : (
              <Link href="/login"><Button>Entrar</Button></Link>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="font-semibold">Anual</div>
            <div className="text-sm text-muted">Melhor custo-benefício</div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-3xl font-semibold">R$ — <span className="text-base text-muted font-normal">/ano</span></div>
            <ul className="text-sm list-disc pl-5 space-y-1">
              <li>Acesso completo ao guia</li>
              <li>Atualizações inclusas</li>
              <li>PWA offline</li>
              <li>Portal Stripe (cancelamento fácil)</li>
            </ul>
            {session?.userId ? (
              <CheckoutButton plan="yearly" label="Assinar anual" />
            ) : (
              <Link href="/login"><Button>Entrar</Button></Link>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <div className="font-semibold">Institucional</div>
            <div className="text-sm text-muted">Hospitais/clínicas (múltiplos usuários). Solicite condições.</div>
          </div>
          <a className="text-brand font-medium hover:underline" href="mailto:contato@exemplo.com">
            Falar com vendas →
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
