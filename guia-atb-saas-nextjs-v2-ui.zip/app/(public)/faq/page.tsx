import { Card, CardContent } from "@/components/ui/Card";
import { AccordionSection } from "@/components/AccordionSection";

export default function FAQ() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">FAQ</h1>

      <div className="grid gap-3">
        <AccordionSection title="De onde vem o conteúdo?" defaultOpen>
          Todo o conteúdo clínico é baseado 100% no PDF “Guia Prático — Antibioticoterapia (Adulto)”. O app reorganiza para busca/visualização, sem criar condutas novas.
        </AccordionSection>

        <AccordionSection title="Vocês resumem ou inventam doses?">
          Não. Não resumimos nem omitimos informações clínicas. Se houver ambiguidade no material, sinalizamos como “conferir no guia” e mantemos o texto original.
        </AccordionSection>

        <AccordionSection title="Como funcionam as atualizações?">
          O app mostra “Versão do conteúdo” e data de atualização. Mantemos um log de mudanças sem expor o conteúdo premium.
        </AccordionSection>

        <AccordionSection title="Offline funciona como?">
          Assinantes podem instalar como PWA e usar offline, com cache seguro. Importante: atualize quando estiver online para receber novas versões.
        </AccordionSection>

        <AccordionSection title="Cancelamento e cobrança">
          Pagamentos e gestão de assinatura são feitos via Stripe. Você pode cancelar a qualquer momento pelo portal do cliente.
        </AccordionSection>

        <AccordionSection title="Responsabilidade">
          É um material de apoio. Não substitui julgamento clínico. Checar alergias, função renal/hepática, gestação/lactação, interações e resistência local.
        </AccordionSection>
      </div>

      <Card>
        <CardContent className="text-sm text-muted">
          Se quiser incluir termos legais (Política de Privacidade / Termos), o projeto já está pronto para adicionar páginas públicas dedicadas.
        </CardContent>
      </Card>
    </div>
  );
}
