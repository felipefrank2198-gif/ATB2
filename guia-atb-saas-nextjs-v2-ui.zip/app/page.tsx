import Link from "next/link";
import { Card, CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { DisclaimerBanner } from "@/components/DisclaimerBanner";

export default function Landing() {
  return (
    <div className="space-y-10">
      <section className="grid gap-8 md:grid-cols-2 md:items-center">
        <div>
          <h1 className="text-3xl md:text-4xl font-semibold tracking-tight">
            Antibioticoterapia do plantão, em <span className="text-brand">2 cliques</span>.
          </h1>
          <p className="mt-4 text-muted leading-7">
            Transformamos seu PDF em um app rápido, visual e fiel ao guia — com busca instantânea, filtros e modo offline (PWA) para assinantes.
          </p>
          <div className="mt-6 flex gap-3">
            <Link href="/app"><Button>Ver demo</Button></Link>
            <Link href="/pricing"><Button variant="ghost">Ver planos</Button></Link>
          </div>

          <div className="mt-6">
            <DisclaimerBanner />
          </div>
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="text-sm font-semibold">O que você ganha</div>
            <ul className="mt-3 list-disc pl-5 text-sm text-slate-800 space-y-2">
              <li><span className="font-medium">Busca global</span> por patologia, patógeno, antibiótico, dose, via e duração.</li>
              <li><span className="font-medium">Visão rápida</span> + visão completa (conteúdo integral do guia).</li>
              <li><span className="font-medium">Copiar</span> esquema formatado para prontuário/WhatsApp.</li>
              <li><span className="font-medium">Imprimir/PDF</span> da página com marca d’água e data.</li>
              <li><span className="font-medium">Favoritos</span>, recentes e atalhos do plantão.</li>
            </ul>
            <div className="mt-6 flex gap-3">
              <Link href="/pricing"><Button variant="secondary">Assinar</Button></Link>
              <Link href="/faq" className="text-sm text-brand hover:underline self-center">Dúvidas? FAQ</Link>
            </div>
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {[
          { t: "Rápido", d: "Index local e UI otimizada para encontrar dose e duração com o mínimo de cliques." },
          { t: "Fiel ao guia", d: "Sem inventar esquemas. Se algo estiver ambíguo, sinalizamos “conferir no guia”." },
          { t: "Seguro", d: "Disclaimers, checagens e foco em stewardship (conforme o material base)." },
        ].map((c) => (
          <Card key={c.t}>
            <CardContent>
              <div className="font-semibold">{c.t}</div>
              <div className="mt-2 text-sm text-muted leading-6">{c.d}</div>
            </CardContent>
          </Card>
        ))}
      </section>
    </div>
  );
}
