export default function Head() {
  return (
    <>
      <meta name="theme-color" content="#2563eb" />
      <link rel="manifest" href="/manifest.json" />
      <link rel="icon" href="/icons/icon-192.png" />
    </>
  );
}
