export type GuideAddendum =
  | { type: "image"; label: string; src: string; page: number; note?: string };

export type GuideNode = {
  id: string;
  system: string;
  type: "pathology" | "topic";
  title: string;
  slug: string;
  source: { pdf: string; toc_page: number; page_start: number; page_end: number };
  rawText: string | null;
  isDemo?: boolean;
  addenda?: GuideAddendum[];
};

export type GuideSystem = { slug: string; name: string; count: number };

export type GuideData = {
  meta: {
    title: string;
    contentVersion: string;
    sourcePdf: string;
    generatedAt: string;
  };
  systems: GuideSystem[];
  nodes: GuideNode[];
};
