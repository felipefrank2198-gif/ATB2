import type { GuideData, GuideNode } from "@/lib/types";
import publicGuide from "@/data/guide.public.json";
import privateGuide from "@/data/guide.private.json";

export function getPublicGuide(): GuideData {
  return publicGuide as unknown as GuideData;
}

export function getPrivateGuide(): GuideData {
  // Server-only: ensure this is never imported in client components.
  return privateGuide as unknown as GuideData;
}

export function findNodeBySlug(guide: GuideData, slug: string): GuideNode | undefined {
  return guide.nodes.find((n) => n.slug === slug);
}
