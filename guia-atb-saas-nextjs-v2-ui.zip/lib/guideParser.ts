export type ParsedSection = {
  title: string;
  content: string;
};

function isHeadingLine(line: string): boolean {
  const l = line.trim();
  if (!l) return false;
  if (l.length > 90) return false;

  // Avoid treating bullet lines as headings
  if (/^[•\-–]\s+/.test(l)) return false;

  // Common guide headings
  if (/^CAP[IÍ]TULO\b/i.test(l)) return true;
  if (/^\d+(?:\.\d+)*\s+/.test(l)) return true; // e.g., 3.1 ...
  if (/^(DEFINI[CÇ][AÃ]O|QUADRO\s+CL[IÍ]NICO|DIAGN[ÓO]STICO|PAT[ÓO]GENOS|TRATAMENTO|FALHA\s+TERAP[ÊE]UTICA|GRAVIDADE|CRIT[ÉE]RIOS|CONDUTA\s+FINAL|PASSO\s+A\s+PASSO)\b/i.test(l)) return true;

  // ALL CAPS headings (Portuguese accents supported loosely)
  const hasLetters = /[A-ZÁÉÍÓÚÇ]/.test(l);
  const isAllCaps = hasLetters && l === l.toUpperCase();
  if (isAllCaps && l.replace(/[^A-ZÁÉÍÓÚÇ]/g, "").length >= 4) return true;

  return false;
}

/**
 * Splits rawText into sections by heuristically detecting heading lines.
 * Safety rule: NEVER edits content; only groups lines.
 */
export function splitIntoSections(rawText: string): ParsedSection[] {
  const lines = rawText.replace(/\r\n/g, "\n").split("\n");
  const sections: ParsedSection[] = [];

  let currentTitle = "Texto";
  let current: string[] = [];

  const push = () => {
    const content = current.join("\n").trim();
    if (!content) return;
    sections.push({ title: currentTitle, content });
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (isHeadingLine(line)) {
      // Start new section
      push();
      currentTitle = line.trim();
      current = [];
      continue;
    }
    current.push(line);
  }
  push();

  // If we failed to split meaningfully, return single section
  if (sections.length <= 1) return [{ title: "Conteúdo completo", content: rawText.trim() }];

  return sections;
}

export type QuickView = {
  treatment?: string;
  pathogens?: string;
  diagnosis?: string;
  severity?: string;
  failure?: string;
  notes?: string;
};

function pickByKeyword(sections: ParsedSection[], keyword: RegExp): string | undefined {
  const s = sections.find((x) => keyword.test(x.title));
  if (s) return s.content.trim();
  return undefined;
}

/**
 * Builds a conservative Quick View. If a block cannot be found safely, it is omitted.
 * The Full View must always remain available.
 */
export function buildQuickView(rawText: string): QuickView {
  const sections = splitIntoSections(rawText);

  const treatment = pickByKeyword(sections, /TRATAMENTO/i);
  const pathogens = pickByKeyword(sections, /PAT[ÓO]GENOS/i);
  const diagnosis = pickByKeyword(sections, /DIAGN[ÓO]STICO|QUADRO\s+CL[IÍ]NICO/i);
  const severity = pickByKeyword(sections, /GRAVIDADE|CRIT[ÉE]RIOS/i);
  const failure = pickByKeyword(sections, /FALHA\s+TERAP/i);

  // If nothing matched, fallback to first ~40 lines (still verbatim)
  let notes: string | undefined;
  if (!treatment && !pathogens && !diagnosis && !severity && !failure) {
    const first = rawText.replace(/\r\n/g, "\n").split("\n").slice(0, 40).join("\n").trim();
    notes = first ? first : undefined;
  }

  return { treatment, pathogens, diagnosis, severity, failure, notes };
}
