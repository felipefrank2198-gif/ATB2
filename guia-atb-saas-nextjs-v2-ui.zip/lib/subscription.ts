import { prisma } from "@/lib/prisma";

export async function getUserSubscription(userId: string) {
  return prisma.subscription.findUnique({ where: { userId } });
}

export async function userHasActiveSubscription(userId: string) {
  const sub = await getUserSubscription(userId);
  if (!sub) return false;
  return sub.status === "active" || sub.status === "trialing";
}
